<!DOCTYPE HTML>
<!--
	Solid State by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Solid State by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />

        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
        <!-- Default theme -->
        <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css"/>
        <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
        <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>

	</head>
	<body class="is-preload">

        <?php if(session()->has('success')): ?>
            <script>
        alertify.set('notifier','position', 'bottom-right');
        alertify.success('we will contact you in few hours');
             </script>
        <?php endif; ?>
        <?php if(session()->has('suc')): ?>
            <script>
        alertify.set('notifier','position', 'bottom-right');
        alertify.success('Done');
             </script>
        <?php endif; ?>
		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header" class="alt"  >
						<h1><a href="index.html" >Solid State</a></h1>
						<nav>
							<a href="#menu">Menu</a>
						</nav>
					</header>

				<!-- Menu -->
					<nav id="menu" >
						<div class="inner" >
							<h2>Menu</h2>
							<ul class="links" >
								<li><a href="/">Home</a></li>
                                <?php if(auth()->guard()->check()): ?>

                                <?php if(auth()->user()->type == 'admin'): ?>

								<li><a href="<?php echo e(route('contact.index')); ?>">Contact</a></li>
								<li><a href="<?php echo e(route('project.index')); ?>">Projects</a></li>
								<li><a href="<?php echo e(route('site.edit',$site->id)); ?>">Edit site setting</a></li>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php if(auth()->guard()->guest()): ?>
                                    <li><a href="<?php echo e(route('login')); ?>">Log In</a></li>
                                    <li><a href="<?php echo e(route('register')); ?>">Sign Up</a></li>
                                    <?php else: ?>
                                    <li class="nav-item dropdown">
                                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                            <?php echo e(Auth::user()->name); ?>

                                        </a>

                                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                            <a class="dropdown-item" href="#"
                                               onclick="event.preventDefault();
                                                             document.getElementById('logout-form').submit();">
                                                <?php echo e(__('Logout')); ?>

                                            </a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="post" class="d-none">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </div>
                                    </li>

                                <?php endif; ?>

							</ul>
							<a href="#" class="close">Close</a>
						</div>
					</nav>

				<!-- Banner -->
					<section id="banner"  >
						<div class="inner">
                            
							<div class="logo"><span class="icon fa-gem"></span></div>
							<h2><?php echo e($site->title1); ?></h2>
							<p><?php echo e($site->sub1); ?></p>
						</div>
					</section>

				<!-- Wrapper -->
					<section id="wrapper">

						<!-- One -->
                        <section  class="wrapper alt  spotlight style2"  >
                            <div class="inner">
                                <a href="#" class="image"><img src="https://i.pinimg.com/564x/e4/f9/67/e4f9676d8b701ce5750775c7d8bef985.jpg" width="260px" height="260px" style="border-radius: 50%" /></a>
                                <div class="content">
                                    <h2 class="major">what we do </h2>
                                    <p>Residential, Administrative, Commercial, Tourist. you can design your home, your hotel, your Resturant  and your office</p>
                                    
                                </div>
                            </div>
                        </section>


						<!-- Two -->
                        <section id="one" class="wrapper spotlight style1"  >
                            <div class="inner">
                                <a href="#" class="image"><img src="<?php echo e('site/'.$site->image); ?>" alt="" /></a>
                                <div class="content">
                                    <h2 class="major"><?php echo e($site->about_us); ?> </h2>
                                    <p><?php echo e($site->sub2); ?></p>
                                    
                                </div>
                            </div>
                        </section>

						

                            <!-- six -->
							<section id="four" class="wrapper alt style1" >
								<div class="inner">
									<h2 class="major">Our Projects</h2>
									<p>Balancing the aspects of modernism with extreme luxurious principals of design.</p>
									<section class="features">
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<article  >
											<a href="<?php echo e(route('project.show', $project->id)); ?>" class="image"><img src="<?php echo e('cover/'. $project->cover); ?>" height="300px" /></a>
											<h3 class="major"><?php echo e($project->title); ?></h3>
											<p><?php echo e($project->desc); ?>.</p>
											<a href="<?php echo e(route('project.show', $project->id)); ?>" class="special">view project</a>
										</article>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</section>
									<ul class="actions">
										<li><a href="<?php echo e(route('browse.all')); ?>" class="button">Browse All</a></li>
									</ul>
								</div>
							</section>

					</section>

				<!-- Footer -->
					<section id="footer">
						<div class="inner">
							<h2 class="major">Get in touch</h2>
							<p>Cras mattis ante fermentum, malesuada neque vitae, eleifend erat. Phasellus non pulvinar erat. Fusce tincidunt, nisl eget mattis egestas, purus ipsum consequat orci, sit amet lobortis lorem lacus in tellus. Sed ac elementum arcu. Quisque placerat auctor laoreet.</p>
							<form method="post" action="<?php echo e(route('contact.store')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
								<div class="fields">
									<div class="field">
										<label for="name">Name</label>
										<input type="text" name="name" id="name" class=" <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div  class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
									<div class="field">
										<label for="email">Email</label>
										<input type="email" name="email" id="email"  class=" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div  class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
									<div class="field">
										<label for="message">Message</label>
										<textarea name="message" id="message" rows="4" class=" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div  class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
									<div class="field">
										<label for="Image">Image</label>
										<input type="file" name="image" id="Image" rows="4" class=" <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <small style="font-size: 14px; color:rgb(144, 184, 72)">image is optional</small>
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div  class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
								</div>
								<ul class="actions">
									<li><input type="submit" value="Send Message" /></li>
								</ul>
							</form>
							<ul class="contact">
								<li class="icon solid fa-home">
									Egypt<br />
									Al-sharqia<br />
									Minya al-Qamh
								</li>
								<li class="icon solid fa-phone">01022953646</li>
								
								<li class="icon brands fa-behance"><a href="https://www.behance.net/amiraelsayb861">https://www.behance.net/amiraelsayb861</a></li>
								<li class="icon brands fa-facebook-f"><a href="https://www.facebook.com/HomeCurve">https://www.facebook.com/HomeCurve</a></li>
								<li class="icon brands fa-instagram"><a href="https://www.instagram.com/amira.elsayed.innovation/">https://www.instagram.com/amira.elsayed.innovation/</a></li>
							</ul>
							<ul class="copyright">
								<li>&copy; Untitled Inc. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a>&nbsp; &nbsp;&nbsp; Made by Ahmed Yasser  &nbsp; &nbsp;&nbsp;  Phone : 01011017982</li>
							</ul>
						</div>
					</section>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>


	</body>
</html>
<?php /**PATH E:\laravel\amira\resources\views/home.blade.php ENDPATH**/ ?>